#include <iostream>
#include "header.h"
#include <string.h>

int main()
{
    /*problema 1
    nod*cap=NULL;
    int x;
    std::cin>>x;
    while (x>0);
    {   
        inserare_cap(cap,x);
        std::cin>>x;
    }

    */

    /*problema 2
    nod2*lista=NULL;
    char optiune[20]={},nume[20],telefon[20];
   
    while(1)
    {
        std::cout<<"Ce optiune alegi? ";
        std::cin>>optiune;
        if(strcmp(optiune,"0")==0)
        {
            break;
        }
        if(strcmp(optiune,"ins")==0)
        {
            std::cout<<"nume: ";
            std::cin>>nume;
            std::cout<<std::endl;
            std::cout<<"telefon: ";
            std::cin>>telefon;
            inserare2(lista,nume,telefon);
        }
        if(strcmp(optiune,"sterg")==0)
        {
            std::cout<<"nume: ";
            std::cin>>nume;
            std::cout<<std::endl;
            sterge2(lista,nume);
        }
        if(strcmp(optiune,"cauta")==0)
        {
            std::cout<<"nume: ";
            std::cin>>nume;
            std::cout<<std::endl;
            cautaretelefon(lista,nume);
        }
        if(strcmp(optiune,"afis")==0)
        {
            afis2(lista);
        }
    }
    */
    
    /*problema 3
    nod* lista1=NULL;
    nod* lista2=NULL;
    inserare_cap(lista1,4);
    inserare_cap(lista1,3);
    inserare_cap(lista1,2);
    inserare_cap(lista1,1);
    inserare_cap(lista1,0);
    
    afis(lista1);
    inserare_cap(lista2,2028);
    inserare_cap(lista2,2027);
    inserare_cap(lista2,2026);
    inserare_cap(lista2,2025);
    inserare_cap(lista2,2024);
    inserare_cap(lista2,2023);
    inserare_cap(lista2,2022);
    inserare_cap(lista2,2021);
    afis(lista2);
    nod*lista3=interclass(lista1,lista2);
    afis(lista3);
    */
    return 0;
}